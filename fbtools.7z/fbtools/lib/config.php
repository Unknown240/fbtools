<?php
$user = "vjlinggarav@yahoo.com";
$pass = "syisidiva69";
$r_male = "1";
$r_female = "2";
$max_status = "1";
?>