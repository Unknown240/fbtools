# FB-Tools
# Mod Unknown240 /Clvnfrlnsyh

# Features
- Get Your Token Fb
- Fb - Reactions (Home)
- Comment On Status Group Facebook

# Usage
bash run

# Contact me On TELEGRAM
t.me/clvnfrlnsyh
